<?php
// index.php
ini_set('display_errors', 0);
ini_set('display_startup_errors', 1);
error_reporting(0);

// Aktifkan output buffering untuk mencegah output tidak terduga mengganggu JSON
ob_start();

// Pengaturan error reporting untuk debugging (NONAKTIFKAN DI PRODUKSI!)


// Sertakan file konfigurasi dan controller
require_once 'corsheader.php';
require_once 'db_connect.php';
require_once 'controllers/BaseController.php'; // Pastikan BaseController di-require sebelum controller lain
require_once 'controllers/PekerjaanController.php';
require_once 'controllers/KriteriaController.php';
require_once 'controllers/AHPController.php';
require_once 'controllers/ProfileMatchingController.php';
require_once 'controllers/RecommendationController.php';

$method = $_SERVER['REQUEST_METHOD'];
$request_uri = explode('/', trim($_SERVER['REQUEST_URI'], '/'));

$path_index = array_search('backend-rekomendasi-karir', $request_uri);
$path = ($path_index !== false) ? array_slice($request_uri, $path_index + 1) : $request_uri;

$controller = $path[0] ?? '';
$id = $path[1] ?? null;
$action = $path[2] ?? null;

$input = json_decode(file_get_contents('php://input'), true);

switch ($controller) {
    case 'pekerjaan':
        $pekerjaanController = new PekerjaanController($conn);
        if ($method == 'GET') {
            if ($id) {
                $pekerjaanController->getById($id);
            } else {
                $pekerjaanController->getAll();
            }
        } elseif ($method == 'POST') {
            $pekerjaanController->create($input);
        } elseif ($method == 'PUT') {
            $pekerjaanController->update($id, $input);
        } elseif ($method == 'DELETE') {
            $pekerjaanController->delete($id);
        }
        break;

    case 'kriteria':
        $kriteriaController = new KriteriaController($conn);
        if ($method == 'GET') {
            if ($id) {
                $kriteriaController->getById($id);
            } else {
                $kriteriaController->getAllGlobal();
            }
        } elseif ($method == 'POST') {
            $kriteriaController->createGlobal($input);
        } elseif ($method == 'PUT') {
            $kriteriaController->updateGlobal($id, $input);
        } elseif ($method == 'DELETE') {
            $kriteriaController->deleteGlobal($id);
        }
        break;

    case 'pekerjaan_kriteria':
        $kriteriaController = new KriteriaController($conn);
        if ($method == 'GET' && $id) {
            $kriteriaController->getJobCriteria($id);
        } elseif ($method == 'POST' && $action == 'toggle') {
            $kriteriaController->toggleJobCriterion($input);
        }
        break;

    case 'sub_kriteria_global': // ROUTE UNTUK MENGELOLA SUB-KRITERIA GLOBAL
        $kriteriaController = new KriteriaController($conn);
        if ($method == 'GET') {
            if ($id) { // Untuk getByIdSubCriterionGlobal
                $kriteriaController->getByIdSubCriterionGlobal($id);
            } else { // Untuk getAllSubCriteriaGlobal
                $kriteriaController->getAllSubCriteriaGlobal();
            }
        } elseif ($method == 'POST') {
            $kriteriaController->createSubCriterionGlobal($input);
        } elseif ($method == 'PUT' && $id) {
            $kriteriaController->updateSubCriterionGlobal($id, $input);
        } elseif ($method == 'DELETE' && $id) {
            $kriteriaController->deleteSubCriterionGlobal($id);
        }
        break;

    case 'pekerjaan_sub_kriteria_detail': // ROUTE UNTUK MENGELOLA DETAIL SUB-KRITERIA PER PEKERJAAN
        $kriteriaController = new KriteriaController($conn);
        if ($method == 'GET' && $id == 'active' && isset($path[2])) { // GET /pekerjaan_sub_kriteria_detail/active/{pekerjaan_id}
            $pekerjaanId = $path[2];
            $kriteriaController->getJobSubCriteriaDetail($pekerjaanId, true); // True untuk hanya yang aktif
        } elseif ($method == 'GET' && $id) { // GET /pekerjaan_sub_kriteria_detail/{pekerjaan_id} (untuk semua sub-kriteria pekerjaan)
             $kriteriaController->getJobSubCriteriaDetail($id, false); // False untuk semua (aktif/tidak aktif)
        } elseif ($method == 'POST' && $action == 'toggle') { // POST /pekerjaan_sub_kriteria_detail/toggle
            $kriteriaController->toggleJobSubCriterionDetail($input);
        } elseif ($method == 'PUT' && isset($path[1]) && $path[2] == 'nilai_ideal') { // PUT /pekerjaan_sub_kriteria_detail/{id}/nilai_ideal
            $psdId = $path[1];
            $kriteriaController->updateNilaiIdealSubCriterionDetail($psdId, $input);
        } elseif ($method == 'DELETE' && $id) {
            $kriteriaController->deleteJobSubCriterionDetail($id);
        }
        break;

    case 'ahp':
        $ahpController = new AHPController($conn);
        if ($method == 'GET' && $id == 'matriks_perbandingan' && isset($path[2])) {
            $pekerjaanId = $path[2];
            $ahpController->getMatriksPerbandingan($pekerjaanId);
        } elseif ($method == 'POST' && $id == 'matriks_perbandingan') {
            $ahpController->saveMatriksPerbandingan($input);
        } elseif ($method == 'POST' && $id == 'hitung_dan_simpan' && isset($path[2])) {
            $pekerjaanId = $path[2];
            $ahpController->calculateAndSaveAHP($pekerjaanId);
        } elseif ($method == 'GET' && $id == 'hasil_bobot' && isset($path[2])) {
            $pekerjaanId = $path[2];
            $ahpController->getAHPBobot($pekerjaanId);
        }
        break;

    case 'pm':
        $pmController = new ProfileMatchingController($conn);
        // Endpoint nilai_ideal_sub (lama) mungkin sudah tidak relevan
        if ($method == 'POST' && $id == 'nilai_ideal_sub') {
            $pmController->saveNilaiIdealSub($input);
        } elseif ($method == 'GET' && $id == 'nilai_ideal_sub' && isset($path[2])) {
            $pekerjaanId = $path[2];
            $pmController->getNilaiIdealSub($pekerjaanId);
        } elseif ($method == 'POST' && $id == 'hitung_dan_simpan' && isset($path[2])) {
            $pekerjaanId = $path[2];
            $pmController->calculateAndSavePM($pekerjaanId);
        }
        break;

    case 'rekomendasi':
        $recController = new RecommendationController($conn);
        if ($method == 'GET' && $id == 'pekerjaan') {
            $recController->getRecommendedJobs();
        } elseif ($method == 'POST' && $id == 'hitung') {
            $recController->calculateUserRecommendation($input);
        }
        // Endpoint /rekomendasi/statistik/{pekerjaan_id} DIHAPUS DARI ROUTER INI
        // Karena sudah dipindahkan ke statistics.php
        break;

    default:
        http_response_code(404);
        echo json_encode(["message" => "Endpoint tidak ditemukan."]);
        break;
}

$conn->close();
ob_end_flush();