<?php
// controllers/BaseController.php
require_once 'corsheader.php';
class BaseController {
    protected $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    protected function sendResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        echo json_encode($data);
        exit; // Pastikan ini ada
    }

    protected function sendError($message, $statusCode = 500) {
        http_response_code($statusCode);
        echo json_encode(["message" => $message]);
        exit; // Pastikan ini ada
    }
}