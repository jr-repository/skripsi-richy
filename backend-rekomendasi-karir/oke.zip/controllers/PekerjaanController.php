<?php
// controllers/PekerjaanController.php
require_once 'corsheader.php';
require_once 'BaseController.php';

class PekerjaanController extends BaseController {
    public function getAll() {
        // MODIFIKASI: Menambahkan JOIN ke pm_hasil_rekomendasi untuk mendapatkan nilai_total_ahp_pm
        $sql = "SELECT p.id, p.nama, p.rata_rata_gaji, p.deskripsi, pmhr.nilai_total_ahp_pm
                FROM pekerjaan p
                LEFT JOIN pm_hasil_rekomendasi pmhr ON p.id = pmhr.pekerjaan_id
                ORDER BY p.nama ASC"; // Order by name for consistency
        $result = $this->conn->query($sql);
        $pekerjaan = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                // Konversi nilai_total_ahp_pm ke float jika tidak null
                $row['nilai_total_ahp_pm'] = $row['nilai_total_ahp_pm'] !== null ? (float)$row['nilai_total_ahp_pm'] : null;
                $pekerjaan[] = $row;
            }
        }
        $this->sendResponse($pekerjaan);
    }

    public function getById($id) {
        $stmt = $this->conn->prepare("SELECT id, nama, rata_rata_gaji, deskripsi FROM pekerjaan WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $this->sendResponse($result->fetch_assoc());
        } else {
            $this->sendError("Pekerjaan tidak ditemukan.", 404);
        }
        $stmt->close();
    }

    public function create($data) {
        if (!isset($data['nama']) || !isset($data['rata_rata_gaji']) || !isset($data['deskripsi'])) {
            $this->sendError("Data tidak lengkap.", 400);
            return;
        }
        $stmt = $this->conn->prepare("INSERT INTO pekerjaan (nama, rata_rata_gaji, deskripsi) VALUES (?, ?, ?)");
        $stmt->bind_param("sds", $data['nama'], $data['rata_rata_gaji'], $data['deskripsi']);
        if ($stmt->execute()) {
            $this->sendResponse(["message" => "Pekerjaan berhasil ditambahkan.", "id" => $stmt->insert_id], 201);
        } else {
            $this->sendError("Gagal menambahkan pekerjaan: " . $stmt->error);
        }
        $stmt->close();
    }

    public function update($id, $data) {
        if (!isset($data['nama']) || !isset($data['rata_rata_gaji']) || !isset($data['deskripsi'])) {
            $this->sendError("Data tidak lengkap.", 400);
            return;
        }
        $stmt = $this->conn->prepare("UPDATE pekerjaan SET nama = ?, rata_rata_gaji = ?, deskripsi = ? WHERE id = ?");
        $stmt->bind_param("sdsi", $data['nama'], $data['rata_rata_gaji'], $data['deskripsi'], $id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $this->sendResponse(["message" => "Pekerjaan berhasil diperbarui."]);
            } else {
                $this->sendError("Pekerjaan tidak ditemukan atau tidak ada perubahan.", 404);
            }
        } else {
            $this->sendError("Gagal memperbarui pekerjaan: " . $stmt->error);
        }
        $stmt->close();
    }

    public function delete($id) {
        $stmt = $this->conn->prepare("DELETE FROM pekerjaan WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            if ($stmt->affected_rows > 0) {
                $this->sendResponse(["message" => "Pekerjaan berhasil dihapus."]);
            } else {
                $this->sendError("Pekerjaan tidak ditemukan.", 404);
            }
        } else {
            $this->sendError("Gagal menghapus pekerjaan: " . $stmt->error);
        }
        $stmt->close();
    }
}